package br.com.fiap.bean;

public class teste {

	public static void main(String[] args) {

		
	}

}
